<?php

namespace App\Livewire\Sparepart\Inventory;

use Livewire\Component;
use App\Models\SparePartProductStock;
use Livewire\Attributes\Layout;

#[Layout('components.layouts.spare-part-app')]
class StockList extends Component
{
    public $stocks;
    public $editId = null;
    public $editData = [];
    public $stock_id;
    public $searchTerm = '';
    protected $listeners = ['delete'];
    public function mount()
    {
        $this->loadStocks();
    }

    public function loadStocks()
    {
        $query = SparePartProductStock::query();
        if ($this->searchTerm) {
            $query->where(function($q) {
                $q->where('partname', 'like', '%' . $this->searchTerm . '%')
                  ->orWhere('part_no', 'like', '%' . $this->searchTerm . '%');
            });
        }
        $this->stocks = $query->orderByDesc('id')->get();
    }

    public function updatedSearchTerm()
    {
        $this->loadStocks();
    }
    public function resetFilters()
    {
        $this->searchTerm = '';
        $this->loadStocks();
    }

    public function edit($id)
    {
        $stock = SparePartProductStock::findOrFail($id);
        $this->editId = $id;
        $this->editData = $stock->toArray();
    }

    public function update()
    {
        $stock = SparePartProductStock::findOrFail($this->editId);
        $stock->update($this->editData);
        $this->editId = null;
        $this->editData = [];
        $this->loadStocks();
        session()->flash('success', 'Stock updated successfully!');
    }


    public function confirmDelete($id)
    {
        $this->stock_id = $id;
        $this->dispatch('swal:confirm', [
            'title' => 'Are you sure?',
            'text' => 'This action cannot be undone.',
            'icon' => 'warning',
            'showCancelButton' => true,
            'confirmButtonText' => 'Yes, delete it!',
            'cancelButtonText' => 'Cancel',
            'action' => 'delete',
        ]);
    }

    public function delete()
    {    
        $stock = SparePartProductStock::findOrFail($this->stock_id);
        $stock->delete();
        $this->dispatch('swal:toast', [
            'type' => 'success',
            'message' => 'Stock deleted successfully!'
        ]);
        $this->loadStocks();
    }

    // public function delete($id)
    // {
    //     SparePartProductStock::findOrFail($id)->delete();
    //     $this->loadStocks();
    //     session()->flash('success', 'Stock deleted successfully!');
    // }

    public function render()
    {
        return view('livewire.sparepart.inventory.stock-list');
    }
}
