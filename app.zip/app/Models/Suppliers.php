<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class Suppliers extends Model
{
    use HasFactory,HasRoles;

    protected $guard_name = 'web';
    protected $table = "supplier";

    protected $fillable = [
        'name',
        'lastname'
    ];

   
}
