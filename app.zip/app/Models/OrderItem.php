<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasFactory;
    public function SpareParts(){
        return $this->belongsTo(SparePart::class,'spare_part_id','id')->withTrashed();
    }
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function order(){
        return $this->belongsTo(Order::class);
    }
    
    public function sparePartVendor(){
        return $this->belongsTo(SparePartVendor::class,'user_id');
    }

}

