<div class="container mt-4">
    <h2>Stock List</h2>
    <!-- Filter Section -->
    <div class="row mb-3">
        <div class="col-md-4">
            <input type="text" class="form-control" placeholder="Search by Part Name or Part No." wire:model.live="searchTerm">
        </div>
        <div class="col-md-2">
            <button class="btn btn-secondary" wire:click="resetFilters">Reset</button>
        </div>
    </div>
    @if (session()->has('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <div class="table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Part Name</th>
                    <th>Part No.</th>
                    <th>Company Name</th>
                   {{-- <th>Category</th>--}}
                    <th>Quantity</th>
                    <th>Unit</th>
                    <th>Rack No.</th>
                    <th>Selling Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($stocks as $index => $stock)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        @if($editId === $stock->id)
                            <td><input type="text" wire:model.defer="editData.partname" class="form-control"></td>
                            <td><input type="text" wire:model.defer="editData.part_no" class="form-control"></td>
                            <td><input type="text" wire:model.defer="editData.company_name" class="form-control"></td>
                           {{-- <td><input type="text" wire:model.defer="editData.category" class="form-control"></td>--}}
                            <td><input type="number" wire:model.defer="editData.quantity" class="form-control"></td>
                            <td><input type="text" wire:model.defer="editData.unit" class="form-control"></td>
                            <td><input type="text" wire:model.defer="editData.rack_no" class="form-control"></td>
                            <td><input type="number" wire:model.defer="editData.total_payable" class="form-control"></td>
                            {{--<td>
                                <button class="btn btn-success btn-sm" wire:click="update">Save</button>
                                <button class="btn btn-secondary btn-sm" wire:click="$set('editId', null)">Cancel</button>
                            </td>--}}
                            <td>
                            <i class="bx bx-check-circle text-success me-2" wire:click="update" style="cursor: pointer; font-size: 20px;" title="Save"></i>
                            <i class="bx bx-x-circle text-secondary me-2" wire:click="$set('editId', null)" style="cursor: pointer; font-size: 20px;" title="Cancel"></i>
                            </td>
                        @else
                            <td>{{ $stock->partname }}</td>
                            <td>{{ $stock->part_no }}</td>
                            <td>{{ $stock->company_name }}</td>
                           {{-- <td>{{ $stock->category }}</td>--}}
                            <td>{{ $stock->quantity }}</td>
                            <td>{{ $stock->unit }}</td>
                            <td>{{ $stock->rack_no }}</td>
                            <td>₹{{ number_format($stock->total_payable, 2) }}</td>
                           {{-- <td>
                                <button class="btn btn-primary btn-sm" wire:click="edit({{ $stock->id }})">Edit</button>
                                <button class="btn btn-danger btn-sm" wire:click="delete({{ $stock->id }})" onclick="return confirm('Are you sure?')">Delete</button>
                            </td>--}}
                            <td>
                            <i class="bx bxs-edit me-2 " wire:click="edit({{ $stock->id }})" style="cursor: pointer; font-size: 20px;"></i>
                            <i class="bx bxs-trash me-2" wire:click="confirmDelete({{ $stock->id }})" style="cursor: pointer; font-size: 20px;"></i>
                        </td>
                        @endif
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
